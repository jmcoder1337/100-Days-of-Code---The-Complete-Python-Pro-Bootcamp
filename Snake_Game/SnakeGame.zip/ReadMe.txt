This folder holds 4 python files required to play my snake game. Save them all to the same folder and run the "main.py" file in order to play the game.  You may need to download python onto your system, as well as the turtle module.

As usual, the control keys are the "Up", "Down", "Left", and "Right" arrow keys.

Have fun!